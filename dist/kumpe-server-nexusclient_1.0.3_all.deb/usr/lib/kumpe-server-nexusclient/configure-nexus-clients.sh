#!/usr/bin/env bash
set -euo pipefail

if ! command -v sudo >/dev/null 2>&1; then
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    sudo() { "$@"; }
  else
    echo "Error: sudo is required when not running as root" >&2
    exit 1
  fi
fi

# Client-only configuration script.
# This script does NOT create/update Nexus repositories.

NEXUS_HOST="artifacts.vm.kumpeapps.com"
PYPI_REPO="pypi"
DOCKER_HUB_PROXY="artifacts.vm.kumpeapps.com/docker"
DOCKER_GHCR_PROXY="artifacts.vm.kumpeapps.com/ghcr"
RUN_UPDATE="false"
BLOCK_DIRECT_REGISTRIES="false"
UNBLOCK_DIRECT_REGISTRIES="false"
INSTALL_DOCKER_WRAPPER="false"
REMOVE_DOCKER_WRAPPER="false"

usage() {
  cat <<'EOF'
Usage:
  configure-nexus-clients.sh [options]

Options:
  --nexus-host <host>            Nexus public host (default: artifacts.vm.kumpeapps.com)
  --pypi-repo <name>             Nexus PyPI proxy repo name (default: pypi)
  --docker-hub-proxy <endpoint>  Docker Hub proxy endpoint URL or host:port
                                 (default: artifacts.vm.kumpeapps.com/repository/docker)
  --docker-ghcr-proxy <endpoint> GHCR proxy endpoint URL or host:port
                                 (default: artifacts.vm.kumpeapps.com/repository/ghcr)
  --block-direct-registries      Add /etc/hosts blocks for direct docker.io/ghcr.io registry hosts
  --unblock-direct-registries    Remove /etc/hosts blocks added by this script
  --install-docker-wrapper       Install /usr/local/bin/docker wrapper to rewrite pull refs to Nexus
  --remove-docker-wrapper        Remove wrapper installed by this script
  --update                       Run pip and apt metadata refresh checks
  -h, --help                     Show this help

What it configures (system-wide):
  - /etc/pip.conf
  - /etc/docker/daemon.json
  - /etc/profile.d/nexus-python.sh

Notes:
  - Docker endpoints can be full URLs (https://.../repository/docker) or host:port (http assumed).
  - Docker registry mirrors only work with registry-root endpoints (no path component).
  - Docker CLI cannot pull through Nexus path endpoints; use a dedicated Nexus Docker connector/vhost (host[:port]).
  - Wrapper mode rewrites only `docker pull`; all other docker commands are passed through unchanged.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --nexus-host)
      shift
      NEXUS_HOST="${1:-}"
      ;;
    --pypi-repo)
      shift
      PYPI_REPO="${1:-}"
      ;;
    --docker-hub-proxy)
      shift
      DOCKER_HUB_PROXY="${1:-}"
      ;;
    --docker-ghcr-proxy)
      shift
      DOCKER_GHCR_PROXY="${1:-}"
      ;;
    --update)
      RUN_UPDATE="true"
      ;;
    --block-direct-registries)
      BLOCK_DIRECT_REGISTRIES="true"
      ;;
    --unblock-direct-registries)
      UNBLOCK_DIRECT_REGISTRIES="true"
      ;;
    --install-docker-wrapper)
      INSTALL_DOCKER_WRAPPER="true"
      ;;
    --remove-docker-wrapper)
      REMOVE_DOCKER_WRAPPER="true"
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
  shift
done

if [[ -z "$NEXUS_HOST" || -z "$PYPI_REPO" || -z "$DOCKER_HUB_PROXY" || -z "$DOCKER_GHCR_PROXY" ]]; then
  echo "Error: one or more required option values are empty" >&2
  exit 1
fi

if [[ "$BLOCK_DIRECT_REGISTRIES" == "true" && "$UNBLOCK_DIRECT_REGISTRIES" == "true" ]]; then
  echo "Error: --block-direct-registries and --unblock-direct-registries are mutually exclusive" >&2
  exit 1
fi

if [[ "$INSTALL_DOCKER_WRAPPER" == "true" && "$REMOVE_DOCKER_WRAPPER" == "true" ]]; then
  echo "Error: --install-docker-wrapper and --remove-docker-wrapper are mutually exclusive" >&2
  exit 1
fi

normalize_endpoint_url() {
  local value="$1"
  if [[ "$value" =~ ^https?:// ]]; then
    echo "${value%/}"
  else
    echo "http://${value}"
  fi
}

strip_scheme() {
  local value="$1"
  value="${value#http://}"
  value="${value#https://}"
  echo "${value%/}"
}

is_host_port() {
  local value="$1"
  [[ "$value" =~ ^[a-zA-Z0-9._-]+(:[0-9]+)?$ ]]
}

docker_mirror_supported() {
  local endpoint="$1"
  endpoint="${endpoint#http://}"
  endpoint="${endpoint#https://}"
  [[ "$endpoint" != */* ]]
}

install_docker_wrapper() {
  local docker_prefix="$1"
  local ghcr_prefix="$2"

  sudo env \
    NEXUS_DOCKER_PREFIX="$docker_prefix" \
    NEXUS_GHCR_PREFIX="$ghcr_prefix" \
    python3 - <<'PY'
import os
from pathlib import Path

wrapper_path = Path('/usr/local/bin/docker')
backup_path = Path('/usr/local/bin/docker.original-pre-nexus-wrapper')
marker_text = '# nexus-docker-pull-wrapper'
marker = marker_text.encode('utf-8')
template = """#!/usr/bin/env bash
set -euo pipefail

{marker}

NEXUS_DOCKER_PREFIX=\"{docker_prefix}\"
NEXUS_GHCR_PREFIX=\"{ghcr_prefix}\"

REAL_DOCKER_BIN=\"/usr/bin/docker.original-pre-nexus-wrapper\"
if [[ ! -x \"$REAL_DOCKER_BIN\" ]]; then
  REAL_DOCKER_BIN=\"/usr/bin/docker\"
fi
if [[ ! -x \"$REAL_DOCKER_BIN\" ]]; then
  REAL_DOCKER_BIN=\"$(command -v docker)\"
fi

if [[ -z \"${{REAL_DOCKER_BIN:-}}\" ]]; then
  echo \"Error: unable to find real docker binary\" >&2
  exit 1
fi

SELF=\"$(readlink -f \"$0\")\"
REAL_RESOLVED=\"$(readlink -f \"$REAL_DOCKER_BIN\" || true)\"
if [[ \"$REAL_RESOLVED\" == \"$SELF\" ]]; then
  if [[ -x \"/usr/bin/docker.original-pre-nexus-wrapper\" ]]; then
    REAL_DOCKER_BIN=\"/usr/bin/docker.original-pre-nexus-wrapper\"
  elif [[ -x \"/usr/bin/docker.io\" ]]; then
    REAL_DOCKER_BIN=\"/usr/bin/docker.io\"
  else
    echo \"Error: docker wrapper recursion detected and fallback docker binary not found\" >&2
    exit 1
  fi
fi

is_explicit_registry() {{
  local first_segment=\"$1\"
  [[ \"$first_segment\" == *.* || \"$first_segment\" == *:* || \"$first_segment\" == \"localhost\" ]]
}}

rewrite_image_ref() {{
  local image=\"$1\"
  local remainder
  local first

  if [[ \"$image\" == *'$'* ]]; then
    echo \"$image\"
    return
  fi

  case \"$image\" in
    \"${{NEXUS_DOCKER_PREFIX}}\"/*|\"${{NEXUS_GHCR_PREFIX}}\"/*)
      echo \"$image\"
      return
      ;;
    ghcr.io/*)
      remainder=\"${{image#ghcr.io/}}\"
      echo \"${{NEXUS_GHCR_PREFIX}}/$remainder\"
      return
      ;;
    docker.io/*)
      remainder=\"${{image#docker.io/}}\"
      echo \"${{NEXUS_DOCKER_PREFIX}}/$remainder\"
      return
      ;;
  esac

  if [[ \"$image\" != */* ]]; then
    echo \"${{NEXUS_DOCKER_PREFIX}}/library/$image\"
    return
  fi

  first=\"${{image%%/*}}\"
  if is_explicit_registry \"$first\"; then
    echo \"$image\"
    return
  fi

  echo \"${{NEXUS_DOCKER_PREFIX}}/$image\"
}}

run_compose_with_rewrite() {{
  local -a compose_args=(\"$@\")
  local -a global_opts=()
  local -a subcmd_args=()
  local subcmd=\"\"
  local idx=0
  local token
  local config_json
  local override_file

  while (( idx < ${{#compose_args[@]}} )); do
    token=\"${{compose_args[$idx]}}\"
    case \"$token\" in
      pull|up)
        subcmd=\"$token\"
        subcmd_args=(\"${{compose_args[@]:$((idx + 1))}}\")
        break
        ;;
      *)
        global_opts+=(\"$token\")
        ;;
    esac
    ((idx++))
  done

  if [[ -z \"$subcmd\" ]]; then
    exec \"$REAL_DOCKER_BIN\" compose \"${{compose_args[@]}}\"
  fi

  config_json=\"$($REAL_DOCKER_BIN compose \"${{global_opts[@]}}\" config --format json 2>/dev/null || true)\"
  if [[ -z \"$config_json\" ]]; then
    exec \"$REAL_DOCKER_BIN\" compose \"${{compose_args[@]}}\"
  fi

  override_file=\"$(mktemp /tmp/nexus-compose-override.XXXXXX.yml)\"
  trap 'rm -f \"$override_file\"' EXIT

  NEXUS_DOCKER_PREFIX=\"$NEXUS_DOCKER_PREFIX\" \
  NEXUS_GHCR_PREFIX=\"$NEXUS_GHCR_PREFIX\" \
  COMPOSE_CONFIG_JSON=\"$config_json\" \
  python3 - <<'__NEXUS_COMPOSE_REWRITE_PY__' > \"$override_file\"
import json
import os

docker_prefix = os.environ[\"NEXUS_DOCKER_PREFIX\"]
ghcr_prefix = os.environ[\"NEXUS_GHCR_PREFIX\"]
doc = json.loads(os.environ[\"COMPOSE_CONFIG_JSON\"])
services = doc.get(\"services\", {{}})

def rewrite_image(image: str) -> str:
    if \"$\" in image:
        return image
    if image.startswith(docker_prefix + \"/\") or image.startswith(ghcr_prefix + \"/\"):
        return image
    if image.startswith(\"ghcr.io/\"):
        return ghcr_prefix + \"/\" + image[len(\"ghcr.io/\"):]
    if image.startswith(\"docker.io/\"):
        return docker_prefix + \"/\" + image[len(\"docker.io/\"):]
    if \"/\" not in image:
        return docker_prefix + \"/library/\" + image
    first = image.split(\"/\", 1)[0]
    if \".\" in first or \":\" in first or first == \"localhost\":
        return image
    return docker_prefix + \"/\" + image

rewritten = {{}}
for service_name, service_cfg in services.items():
    image = service_cfg.get(\"image\")
    if not image:
        continue
    new_image = rewrite_image(image)
    if new_image != image:
        rewritten[service_name] = new_image

if not rewritten:
  print(\"services: {{}}\")
else:
  print(\"services:\")
  for name, image in sorted(rewritten.items()):
    print(\"  \" + name + \":\")
    print(\"    image: \" + image)
__NEXUS_COMPOSE_REWRITE_PY__

  if [[ \"${{NEXUS_DOCKER_WRAPPER_DEBUG:-0}}\" == \"1\" ]]; then
    echo \"docker wrapper compose override file: $override_file\" >&2
    sed -n '1,120p' \"$override_file\" >&2
  fi

  exec \"$REAL_DOCKER_BIN\" compose \"${{global_opts[@]}}\" -f \"$override_file\" \"$subcmd\" \"${{subcmd_args[@]}}\"
}}

if [[ \"${{1:-}}\" == \"compose\" ]]; then
  shift
  run_compose_with_rewrite \"$@\"
fi

if [[ \"${{1:-}}\" != \"pull\" ]]; then
  exec \"$REAL_DOCKER_BIN\" \"$@\"
fi

shift
pull_opts=()
image_ref=\"\"
extra=()

for arg in \"$@\"; do
  if [[ -z \"$image_ref\" && \"$arg\" == -* ]]; then
    pull_opts+=(\"$arg\")
    continue
  fi

  if [[ -z \"$image_ref\" ]]; then
    image_ref=\"$arg\"
    continue
  fi

  extra+=(\"$arg\")
done

if [[ -z \"$image_ref\" ]]; then
  exec \"$REAL_DOCKER_BIN\" pull \"${{pull_opts[@]}}\"
fi

rewritten=\"$(rewrite_image_ref \"$image_ref\")\"
if [[ \"${{NEXUS_DOCKER_WRAPPER_DEBUG:-0}}\" == \"1\" && \"$rewritten\" != \"$image_ref\" ]]; then
  echo \"docker wrapper rewrite: $image_ref -> $rewritten\" >&2
fi

exec \"$REAL_DOCKER_BIN\" pull \"${{pull_opts[@]}}\" \"$rewritten\" \"${{extra[@]}}\"
"""

content = template.format(
  marker=marker_text,
    docker_prefix=os.environ['NEXUS_DOCKER_PREFIX'],
    ghcr_prefix=os.environ['NEXUS_GHCR_PREFIX'],
).encode('utf-8')

if wrapper_path.is_symlink():
  wrapper_path.unlink()

if wrapper_path.exists():
  existing = wrapper_path.read_bytes()
  if marker not in existing and not backup_path.exists():
    backup_path.write_bytes(existing)

wrapper_path.write_bytes(content)
wrapper_path.chmod(0o755)

system_docker_path = Path('/usr/bin/docker')
system_backup_path = Path('/usr/bin/docker.original-pre-nexus-wrapper')
system_shim_marker = b'# nexus-docker-shim'
system_shim = b'''#!/usr/bin/env bash
set -euo pipefail
# nexus-docker-shim
exec /usr/local/bin/docker "$@"
'''

if system_docker_path.exists() and not system_docker_path.is_symlink():
  existing_system = system_docker_path.read_bytes()
  if system_shim_marker not in existing_system and marker not in existing_system:
    if not system_backup_path.exists():
      system_backup_path.write_bytes(existing_system)
      system_backup_path.chmod(0o755)
    system_docker_path.write_bytes(system_shim)
    system_docker_path.chmod(0o755)
PY
}

remove_docker_wrapper() {
  sudo python3 - <<'PY'
from pathlib import Path

wrapper_path = Path('/usr/local/bin/docker')
backup_path = Path('/usr/local/bin/docker.original-pre-nexus-wrapper')
marker = b'# nexus-docker-pull-wrapper'
system_docker_path = Path('/usr/bin/docker')
system_backup_path = Path('/usr/bin/docker.original-pre-nexus-wrapper')
system_shim_marker = b'# nexus-docker-shim'

if wrapper_path.exists():
  if wrapper_path.is_symlink():
    wrapper_path.unlink()
  else:
    existing = wrapper_path.read_bytes()
    if marker in existing:
      if backup_path.exists():
        wrapper_path.write_bytes(backup_path.read_bytes())
        backup_path.unlink()
        wrapper_path.chmod(0o755)
      else:
        wrapper_path.unlink()

if system_backup_path.exists():
  if not system_docker_path.exists() or system_docker_path.is_symlink():
    system_docker_path.write_bytes(system_backup_path.read_bytes())
    system_backup_path.unlink()
    system_docker_path.chmod(0o755)
  else:
    existing_system = system_docker_path.read_bytes()
    if system_shim_marker in existing_system:
      system_docker_path.write_bytes(system_backup_path.read_bytes())
      system_backup_path.unlink()
      system_docker_path.chmod(0o755)
PY
}

apply_hosts_blocks() {
  sudo python3 - <<'PY'
from pathlib import Path

hosts_path = Path('/etc/hosts')
start = '# BEGIN nexus-client-registry-blocks'
end = '# END nexus-client-registry-blocks'
block = '\n'.join([
    start,
  '0.0.0.0 registry-1.docker.io',
  ':: registry-1.docker.io',
  '0.0.0.0 auth.docker.io',
  ':: auth.docker.io',
  '0.0.0.0 index.docker.io',
  ':: index.docker.io',
  '0.0.0.0 production.cloudflare.docker.com',
  ':: production.cloudflare.docker.com',
  '0.0.0.0 ghcr.io',
  ':: ghcr.io',
  '0.0.0.0 pkg-containers.githubusercontent.com',
  ':: pkg-containers.githubusercontent.com',
    end,
])

content = hosts_path.read_text(encoding='utf-8') if hosts_path.exists() else ''
if start in content and end in content:
    pre = content.split(start)[0].rstrip('\n')
    post = content.split(end, 1)[1].lstrip('\n')
    content = (pre + '\n' + block + ('\n' + post if post else '\n')).lstrip('\n')
else:
    if content and not content.endswith('\n'):
        content += '\n'
    content += block + '\n'

hosts_path.write_text(content, encoding='utf-8')
PY
}

remove_hosts_blocks() {
  sudo python3 - <<'PY'
from pathlib import Path

hosts_path = Path('/etc/hosts')
if not hosts_path.exists():
    raise SystemExit(0)

start = '# BEGIN nexus-client-registry-blocks'
end = '# END nexus-client-registry-blocks'
content = hosts_path.read_text(encoding='utf-8')
if start in content and end in content:
    pre = content.split(start)[0].rstrip('\n')
    post = content.split(end, 1)[1].lstrip('\n')
    merged = '\n'.join([x for x in [pre, post] if x]).rstrip('\n')
    hosts_path.write_text((merged + '\n') if merged else '', encoding='utf-8')
PY
}

PYPI_SIMPLE_URL="https://${NEXUS_HOST}/repository/${PYPI_REPO}/simple"
DOCKER_HUB_ENDPOINT_URL="$(normalize_endpoint_url "$DOCKER_HUB_PROXY")"
DOCKER_GHCR_ENDPOINT_URL="$(normalize_endpoint_url "$DOCKER_GHCR_PROXY")"
DOCKER_HUB_PREFIX="$(strip_scheme "$DOCKER_HUB_ENDPOINT_URL")"
DOCKER_GHCR_PREFIX="$(strip_scheme "$DOCKER_GHCR_ENDPOINT_URL")"
DOCKER_HUB_MIRROR_SUPPORTED="false"
DOCKER_GHCR_PULL_SUPPORTED="false"

if docker_mirror_supported "$DOCKER_HUB_ENDPOINT_URL"; then
  DOCKER_HUB_MIRROR_SUPPORTED="true"
fi

if docker_mirror_supported "$DOCKER_GHCR_ENDPOINT_URL"; then
  DOCKER_GHCR_PULL_SUPPORTED="true"
fi

if [[ "$INSTALL_DOCKER_WRAPPER" == "true" ]]; then
  if [[ "$DOCKER_HUB_MIRROR_SUPPORTED" != "true" || "$DOCKER_GHCR_PULL_SUPPORTED" != "true" ]]; then
    cat <<EOF >&2
Warning: wrapper install is using path-based Docker endpoints.
This is non-standard and may fail unless your reverse proxy maps these paths to Docker registry roots:
  --docker-hub-proxy=${DOCKER_HUB_PROXY}
  --docker-ghcr-proxy=${DOCKER_GHCR_PROXY}

Preferred dedicated Nexus Docker connector/vhost endpoints are:
  --docker-hub-proxy=nexus-docker.example.com:5000
  --docker-ghcr-proxy=nexus-ghcr.example.com:5001
EOF
  fi
fi

DOCKER_HUB_INSECURE=""
DOCKER_GHCR_INSECURE=""

if is_host_port "$DOCKER_HUB_PROXY"; then
  DOCKER_HUB_INSECURE="$DOCKER_HUB_PROXY"
fi

if is_host_port "$DOCKER_GHCR_PROXY"; then
  DOCKER_GHCR_INSECURE="$DOCKER_GHCR_PROXY"
fi

echo "Applying system-wide pip configuration..."
sudo tee /etc/pip.conf >/dev/null <<EOF
[global]
index-url = ${PYPI_SIMPLE_URL}
trusted-host = ${NEXUS_HOST}
timeout = 60
EOF

echo "Applying global Python env defaults..."
sudo tee /etc/profile.d/nexus-python.sh >/dev/null <<EOF
export PIP_INDEX_URL="${PYPI_SIMPLE_URL}"
export PIP_TRUSTED_HOST="${NEXUS_HOST}"
EOF
sudo chmod 0644 /etc/profile.d/nexus-python.sh

echo "Applying system-wide Docker daemon configuration..."
sudo env \
  DOCKER_HUB_ENDPOINT_URL="$DOCKER_HUB_ENDPOINT_URL" \
  DOCKER_HUB_INSECURE="$DOCKER_HUB_INSECURE" \
  DOCKER_HUB_MIRROR_SUPPORTED="$DOCKER_HUB_MIRROR_SUPPORTED" \
  DOCKER_GHCR_INSECURE="$DOCKER_GHCR_INSECURE" \
  python3 - <<'PY'
import json
import os
from pathlib import Path

config = {}

if os.environ["DOCKER_HUB_MIRROR_SUPPORTED"] == "true":
    config["registry-mirrors"] = [os.environ["DOCKER_HUB_ENDPOINT_URL"]]

insecure = [value for value in [os.environ["DOCKER_HUB_INSECURE"], os.environ["DOCKER_GHCR_INSECURE"]] if value]
if insecure:
    config["insecure-registries"] = insecure

Path("/etc/docker").mkdir(parents=True, exist_ok=True)
Path("/etc/docker/daemon.json").write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
PY

if [[ "$DOCKER_HUB_MIRROR_SUPPORTED" != "true" ]]; then
  cat <<EOF
Warning: ${DOCKER_HUB_ENDPOINT_URL} contains a path, so Docker cannot use it as a registry mirror.
Mirror for docker.io was not configured. To mirror transparently, use a dedicated Nexus Docker connector/vhost on host[:port].
EOF
fi

if [[ "$DOCKER_GHCR_PULL_SUPPORTED" != "true" ]]; then
  cat <<EOF
Warning: ${DOCKER_GHCR_ENDPOINT_URL} contains a path, so Docker CLI cannot pull images through it directly.
Use a dedicated Nexus Docker connector/vhost for GHCR proxying (for example: nexus-ghcr.example.com[:port]).
EOF
fi

if [[ "$UNBLOCK_DIRECT_REGISTRIES" == "true" ]]; then
  echo "Removing direct registry hostname blocks from /etc/hosts..."
  remove_hosts_blocks
fi

if [[ "$BLOCK_DIRECT_REGISTRIES" == "true" ]]; then
  echo "Adding direct registry hostname blocks to /etc/hosts..."
  apply_hosts_blocks
fi

if [[ "$REMOVE_DOCKER_WRAPPER" == "true" ]]; then
  echo "Removing docker pull wrapper from /usr/local/bin/docker..."
  remove_docker_wrapper
fi

if [[ "$INSTALL_DOCKER_WRAPPER" == "true" ]]; then
  echo "Installing docker pull wrapper to /usr/local/bin/docker..."
  install_docker_wrapper "$DOCKER_HUB_PREFIX" "$DOCKER_GHCR_PREFIX"
fi

if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files | grep -q '^docker\.service'; then
  echo "Restarting docker service..."
  sudo systemctl restart docker
fi

echo "Validating configured endpoints..."
curl -sS -I "${PYPI_SIMPLE_URL}/" | sed -n '1,8p'
curl -sS -I "${DOCKER_HUB_ENDPOINT_URL}/v2/" | sed -n '1,8p'
curl -sS -I "${DOCKER_GHCR_ENDPOINT_URL}/v2/" | sed -n '1,8p'

if [[ "$RUN_UPDATE" == "true" ]]; then
  echo "Running metadata refresh checks..."
  python3 -m pip index versions pip >/dev/null || true
  sudo apt-get update >/dev/null || true
fi

cat <<EOF

Done.

All-user configuration set:
  - /etc/pip.conf -> ${PYPI_SIMPLE_URL}
  - /etc/docker/daemon.json -> docker hub mirror ${DOCKER_HUB_ENDPOINT_URL} (supported: ${DOCKER_HUB_MIRROR_SUPPORTED})
  - ghcr pull-through endpoint support -> ${DOCKER_GHCR_PULL_SUPPORTED}

Direct registry block mode:
  - enabled now: ${BLOCK_DIRECT_REGISTRIES}
  - removed now: ${UNBLOCK_DIRECT_REGISTRIES}

Docker wrapper mode:
  - installed now: ${INSTALL_DOCKER_WRAPPER}
  - removed now: ${REMOVE_DOCKER_WRAPPER}

Usage examples:
  pip install requests
  docker pull alpine:latest
  docker pull <nexus-ghcr-host[:port]>/OWNER/IMAGE:TAG
  NEXUS_DOCKER_WRAPPER_DEBUG=1 docker pull ghcr.io/OWNER/IMAGE:TAG

Enforcement notes:
  - For hard enforcement across hosts, block egress to docker.io/ghcr.io at network firewall and allow Nexus only.
EOF
